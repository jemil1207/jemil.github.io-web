var currentYear = new Date().getFullYear();
document.getElementById("copyright").textContent = currentYear;